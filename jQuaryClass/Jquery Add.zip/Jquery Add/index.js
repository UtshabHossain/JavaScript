// let div = $("#myDiv");

// // $("button").click(function () {
// //   div.append("<p>I am from jquery</p>", "<p>Another From Jquery</p>");
// // });

// let count = 0;

// $("button").click(function () {
//   if (count == 0) {
//     div.prepend("<p>I am from jquery</p>");
//     count++;
//   } else if (count == 1) {
//     div.prepend("<p>I am Late</p>");
//     count++;
//   }
// });

// append() , prepend() -> Insert Element as children
// after(), before(), -> Insert Element as sibling

// let p = $("#myp");

// $("button").click(function () {
//   p.before("<p>I am from Jquery</p>");
// });

// let nameField = $("#name");
// let addBtn = $("#addBtn");
// let tbd = $("#tbd");

// let name;
// let elm;
// let sl = 1;

// // addBtn.on('click', function(){})

// addBtn.click(function () {
//   name = nameField.val();

//   elm = "<tr>" + "<td>" + ++sl + "</td>" + "<td>" + name + "</td>" + "</tr>";

//   tbd.append(elm);
//   nameField.val();
// });

// empty(), remove()

// empty() -> remove child elements
// remove() -> remove target element

// $("button").click(function () {
//   //   $("#parent").empty();
//   //   $("#parent").remove();
//   $("p").remove("#rmv");
// });
